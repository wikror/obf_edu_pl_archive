<!DOCTYPE html>
<html dir="ltr" lang="en-US" prefix="og: https://ogp.me/ns#">
<head>
<meta charset="UTF-8" />

<link rel="profile" href="https://gmpg.org/xfn/11" />
<link rel="stylesheet" type="text/css" media="all" href="http://obf.edu.pl/wp-content/themes/twentyten/style.css?ver=20190507" />
<link rel="pingback" href="http://obf.edu.pl/xmlrpc.php">

		<!-- All in One SEO 4.6.8.1 - aioseo.com -->
		<title>Page not found | </title>
		<meta name="robots" content="noindex" />
		<meta name="generator" content="All in One SEO (AIOSEO) 4.6.8.1" />
		<script type="application/ld+json" class="aioseo-schema">
			{"@context":"https:\/\/schema.org","@graph":[{"@type":"BreadcrumbList","@id":"http:\/\/obf.edu.pl\/en\/gdzie-koczy-si-umys\/www.tarabuk.pl\/#breadcrumblist","itemListElement":[{"@type":"ListItem","@id":"http:\/\/obf.edu.pl\/en\/#listItem","position":1,"name":"Dom","item":"http:\/\/obf.edu.pl\/en\/","nextItem":"http:\/\/obf.edu.pl\/en\/gdzie-koczy-si-umys\/www.tarabuk.pl\/#listItem"},{"@type":"ListItem","@id":"http:\/\/obf.edu.pl\/en\/gdzie-koczy-si-umys\/www.tarabuk.pl\/#listItem","position":2,"name":"Nie znaleziono","previousItem":"http:\/\/obf.edu.pl\/en\/#listItem"}]},{"@type":"Organization","@id":"http:\/\/obf.edu.pl\/en\/#organization","name":"Centre for Philosophical Research","url":"http:\/\/obf.edu.pl\/en\/"},{"@type":"WebPage","@id":"http:\/\/obf.edu.pl\/en\/gdzie-koczy-si-umys\/www.tarabuk.pl\/#webpage","url":"http:\/\/obf.edu.pl\/en\/gdzie-koczy-si-umys\/www.tarabuk.pl\/","inLanguage":"en-US","isPartOf":{"@id":"http:\/\/obf.edu.pl\/en\/#website"},"breadcrumb":{"@id":"http:\/\/obf.edu.pl\/en\/gdzie-koczy-si-umys\/www.tarabuk.pl\/#breadcrumblist"}},{"@type":"WebSite","@id":"http:\/\/obf.edu.pl\/en\/#website","url":"http:\/\/obf.edu.pl\/en\/","name":"Centre for Philosophical Research","inLanguage":"en-US","publisher":{"@id":"http:\/\/obf.edu.pl\/en\/#organization"}}]}
		</script>
		<!-- All in One SEO -->

<link rel='dns-prefetch' href='//s.w.org' />
<link rel='dns-prefetch' href='//v0.wordpress.com' />
<link rel='dns-prefetch' href='//i0.wp.com' />
<link rel='dns-prefetch' href='//i1.wp.com' />
<link rel='dns-prefetch' href='//i2.wp.com' />
<link rel="alternate" type="application/rss+xml" title="Centre for Philosophical Research &raquo; Feed" href="http://obf.edu.pl/en/feed/" />
<link rel="alternate" type="application/rss+xml" title="Centre for Philosophical Research &raquo; Comments Feed" href="http://obf.edu.pl/en/comments/feed/" />
		<script type="text/javascript">
			window._wpemojiSettings = {"baseUrl":"https:\/\/s.w.org\/images\/core\/emoji\/13.0.1\/72x72\/","ext":".png","svgUrl":"https:\/\/s.w.org\/images\/core\/emoji\/13.0.1\/svg\/","svgExt":".svg","source":{"concatemoji":"http:\/\/obf.edu.pl\/wp-includes\/js\/wp-emoji-release.min.js?ver=5.7.12"}};
			!function(e,a,t){var n,r,o,i=a.createElement("canvas"),p=i.getContext&&i.getContext("2d");function s(e,t){var a=String.fromCharCode;p.clearRect(0,0,i.width,i.height),p.fillText(a.apply(this,e),0,0);e=i.toDataURL();return p.clearRect(0,0,i.width,i.height),p.fillText(a.apply(this,t),0,0),e===i.toDataURL()}function c(e){var t=a.createElement("script");t.src=e,t.defer=t.type="text/javascript",a.getElementsByTagName("head")[0].appendChild(t)}for(o=Array("flag","emoji"),t.supports={everything:!0,everythingExceptFlag:!0},r=0;r<o.length;r++)t.supports[o[r]]=function(e){if(!p||!p.fillText)return!1;switch(p.textBaseline="top",p.font="600 32px Arial",e){case"flag":return s([127987,65039,8205,9895,65039],[127987,65039,8203,9895,65039])?!1:!s([55356,56826,55356,56819],[55356,56826,8203,55356,56819])&&!s([55356,57332,56128,56423,56128,56418,56128,56421,56128,56430,56128,56423,56128,56447],[55356,57332,8203,56128,56423,8203,56128,56418,8203,56128,56421,8203,56128,56430,8203,56128,56423,8203,56128,56447]);case"emoji":return!s([55357,56424,8205,55356,57212],[55357,56424,8203,55356,57212])}return!1}(o[r]),t.supports.everything=t.supports.everything&&t.supports[o[r]],"flag"!==o[r]&&(t.supports.everythingExceptFlag=t.supports.everythingExceptFlag&&t.supports[o[r]]);t.supports.everythingExceptFlag=t.supports.everythingExceptFlag&&!t.supports.flag,t.DOMReady=!1,t.readyCallback=function(){t.DOMReady=!0},t.supports.everything||(n=function(){t.readyCallback()},a.addEventListener?(a.addEventListener("DOMContentLoaded",n,!1),e.addEventListener("load",n,!1)):(e.attachEvent("onload",n),a.attachEvent("onreadystatechange",function(){"complete"===a.readyState&&t.readyCallback()})),(n=t.source||{}).concatemoji?c(n.concatemoji):n.wpemoji&&n.twemoji&&(c(n.twemoji),c(n.wpemoji)))}(window,document,window._wpemojiSettings);
		</script>
		<style type="text/css">
img.wp-smiley,
img.emoji {
	display: inline !important;
	border: none !important;
	box-shadow: none !important;
	height: 1em !important;
	width: 1em !important;
	margin: 0 .07em !important;
	vertical-align: -0.1em !important;
	background: none !important;
	padding: 0 !important;
}
</style>
	<link rel='stylesheet' id='wp-block-library-css'  href='http://obf.edu.pl/wp-includes/css/dist/block-library/style.min.css?ver=5.7.12' type='text/css' media='all' />
<style id='wp-block-library-inline-css' type='text/css'>
.has-text-align-justify{text-align:justify;}
</style>
<link rel='stylesheet' id='wp-block-library-theme-css'  href='http://obf.edu.pl/wp-includes/css/dist/block-library/theme.min.css?ver=5.7.12' type='text/css' media='all' />
<link rel='stylesheet' id='mediaelement-css'  href='http://obf.edu.pl/wp-includes/js/mediaelement/mediaelementplayer-legacy.min.css?ver=4.2.16' type='text/css' media='all' />
<link rel='stylesheet' id='wp-mediaelement-css'  href='http://obf.edu.pl/wp-includes/js/mediaelement/wp-mediaelement.min.css?ver=5.7.12' type='text/css' media='all' />
<link rel='stylesheet' id='twentyten-block-style-css'  href='http://obf.edu.pl/wp-content/themes/twentyten/blocks.css?ver=20181218' type='text/css' media='all' />
<!-- Inline jetpack_facebook_likebox -->
<style id='jetpack_facebook_likebox-inline-css' type='text/css'>
.widget_facebook_likebox {
	overflow: hidden;
}

</style>
<link rel='stylesheet' id='jetpack_css-css'  href='http://obf.edu.pl/wp-content/plugins/jetpack/css/jetpack.css?ver=10.4.1' type='text/css' media='all' />
<link rel="https://api.w.org/" href="http://obf.edu.pl/en/wp-json/" /><link rel="EditURI" type="application/rsd+xml" title="RSD" href="http://obf.edu.pl/xmlrpc.php?rsd" />
<link rel="wlwmanifest" type="application/wlwmanifest+xml" href="http://obf.edu.pl/wp-includes/wlwmanifest.xml" /> 
<meta name="generator" content="WordPress 5.7.12" />
<meta name="generator" content="Seriously Simple Podcasting 3.4.1" />

<link rel="alternate" type="application/rss+xml" title="Podcast RSS feed" href="http://obf.edu.pl/feed/podcast" />

<style type="text/css">
.qtranxs_flag_pl {background-image: url(http://obf.edu.pl/wp-content/plugins/qtranslate-x/flags/pl.png); background-repeat: no-repeat;}
.qtranxs_flag_en {background-image: url(http://obf.edu.pl/wp-content/plugins/qtranslate-x/flags/gb.png); background-repeat: no-repeat;}
</style>
<meta name="generator" content="qTranslate-X 3.4.6.8" />
<style type='text/css'>img#wpstats{display:none}</style>
		<link rel="icon" href="https://i1.wp.com/obf.edu.pl/wp-content/uploads/2014/09/logo_obf_no_lang-e1412078258369.png?fit=32%2C32" sizes="32x32" />
<link rel="icon" href="https://i1.wp.com/obf.edu.pl/wp-content/uploads/2014/09/logo_obf_no_lang-e1412078258369.png?fit=150%2C151" sizes="192x192" />
<link rel="apple-touch-icon" href="https://i1.wp.com/obf.edu.pl/wp-content/uploads/2014/09/logo_obf_no_lang-e1412078258369.png?fit=150%2C151" />
<meta name="msapplication-TileImage" content="https://i1.wp.com/obf.edu.pl/wp-content/uploads/2014/09/logo_obf_no_lang-e1412078258369.png?fit=150%2C151" />
</head>

<body class="error404">
<div id="wrapper" class="hfeed">
	<div id="header">
		<div id="masthead">
			<div id="branding" role="banner">
								<div id="site-title">
					<span>
						<a href="http://obf.edu.pl/en/" title="Centre for Philosophical Research" rel="home">Centre for Philosophical Research</a>
					</span>
				</div>
				<div id="site-description"></div>

									<img src="http://obf.edu.pl/wp-content/themes/twentyten/images/headers/berries.jpg" width="940" height="198" alt="" />
								</div><!-- #branding -->

			<div id="access" role="navigation">
								<div class="skip-link screen-reader-text"><a href="#content" title="Skip to content">Skip to content</a></div>
				<div class="menu-header"><ul id="menu-navigation" class="menu"><li id="menu-item-537" class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item-has-children menu-item-537"><a href="http://obf.edu.pl/en/category/wydarzenia/">Wydarzenia</a>
<ul class="sub-menu">
	<li id="menu-item-414" class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item-414"><a href="http://obf.edu.pl/en/category/wydarzenia/c21-kawiarnia-fn/">Kawiarnia Filozoficzna</a></li>
	<li id="menu-item-654" class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item-654"><a href="http://obf.edu.pl/en/category/wydarzenia/wyklady/">Wykłady</a></li>
</ul>
</li>
<li id="menu-item-85" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-has-children menu-item-85"><a href="http://obf.edu.pl/en/konferencje/">Konferencje</a>
<ul class="sub-menu">
	<li id="menu-item-815" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-815"><a href="http://ccc-conference.org/">Context, Cognition, and Communication Conference</a></li>
	<li id="menu-item-356" class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item-has-children menu-item-356"><a href="http://obf.edu.pl/en/category/c17-naturalizm-w-kazimierzu/">Kazimierz Naturalist Workshop</a>
	<ul class="sub-menu">
		<li id="menu-item-716" class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item-716"><a href="http://obf.edu.pl/en/category/c17-naturalizm-w-kazimierzu/knew-2014/">KNEW 2014</a></li>
		<li id="menu-item-359" class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item-359"><a href="http://obf.edu.pl/en/category/c17-naturalizm-w-kazimierzu/knew-2013/">KNEW 2013</a></li>
		<li id="menu-item-358" class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item-358"><a href="http://obf.edu.pl/en/category/c17-naturalizm-w-kazimierzu/knew-2012/">KNEW 2012</a></li>
		<li id="menu-item-412" class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item-412"><a href="http://obf.edu.pl/en/category/c17-naturalizm-w-kazimierzu/knew-2011/">KNEW 2011</a></li>
		<li id="menu-item-360" class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item-360"><a href="http://obf.edu.pl/en/category/c17-naturalizm-w-kazimierzu/knew-2010/">KNEW 2010</a></li>
		<li id="menu-item-355" class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item-355"><a href="http://obf.edu.pl/en/category/c17-naturalizm-w-kazimierzu/knew-2009/">KNEW 2009</a></li>
		<li id="menu-item-413" class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item-413"><a href="http://obf.edu.pl/en/category/c17-naturalizm-w-kazimierzu/previous-knews/">Previous KNEWs</a></li>
	</ul>
</li>
	<li id="menu-item-361" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-361"><a href="http://zlot.obf.edu.pl">Zlot Filozoficzny</a></li>
	<li id="menu-item-481" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children menu-item-481"><a href="http://avant.edu.pl/">Trends in Interdisciplinary Studies</a>
	<ul class="sub-menu">
		<li id="menu-item-740" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-740"><a href="http://avant.edu.pl/trends/">Thinking with Hands, Eyes and Things</a></li>
		<li id="menu-item-739" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-739"><a href="http://trends.avant.edu.pl/">Situating Cognition</a></li>
		<li id="menu-item-886" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-886"><a href="http://avant.edu.pl/trends3/">Understanding Social Cognition</a></li>
	</ul>
</li>
	<li id="menu-item-419" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-419"><a href="http://www.psychologia.pl/forum_badan_nad_jezykiem/">Studenckie Forum Badań nad Językiem</a></li>
</ul>
</li>
<li id="menu-item-47" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-has-children menu-item-47"><a href="http://obf.edu.pl/en/wydawnictwo-obf/">Wydawnictwo OBF</a>
<ul class="sub-menu">
	<li id="menu-item-81" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-81"><a href="http://obf.edu.pl/en/wydawnictwo-obf/biblioteka-obf/">Biblioteka OBF</a></li>
	<li id="menu-item-122" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children menu-item-122"><a href="http://avant.edu.pl">Avant</a>
	<ul class="sub-menu">
		<li id="menu-item-416" class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item-416"><a href="http://obf.edu.pl/en/category/avant/">Avant</a></li>
	</ul>
</li>
	<li id="menu-item-422" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-422"><a href="http://obf.edu.pl/en/wydawnictwo-obf/conference-proceedings/">Publikacje pokonferencyjne</a></li>
</ul>
</li>
<li id="menu-item-77" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-has-children menu-item-77"><a title="O Ośrodku Badań Filozoficznych" href="http://obf.edu.pl/en/o-nas/">    O nas    </a>
<ul class="sub-menu">
	<li id="menu-item-431" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-431"><a href="http://obf.edu.pl/en/sklad-osobowy/">Skład osobowy</a></li>
	<li id="menu-item-79" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-79"><a href="http://obf.edu.pl/en/o-nas/kontakt/">Kontakt</a></li>
</ul>
</li>
</ul></div>			</div><!-- #access -->
		</div><!-- #masthead -->
	</div><!-- #header -->

	<div id="main">

	<div id="container">
		<div id="content" role="main">

			<div id="post-0" class="post error404 not-found">
				<h1 class="entry-title">Not Found</h1>
				<div class="entry-content">
					<p>Apologies, but the page you requested could not be found. Perhaps searching will help.</p>
					<form role="search" method="get" id="searchform" class="searchform" action="http://obf.edu.pl/en/">
				<div>
					<label class="screen-reader-text" for="s">Search for:</label>
					<input type="text" value="" name="s" id="s" />
					<input type="submit" id="searchsubmit" value="Search" />
				</div>
			</form>				</div><!-- .entry-content -->
			</div><!-- #post-0 -->

		</div><!-- #content -->
	</div><!-- #container -->
	<script type="text/javascript">
		// Focus on search field after it has loaded.
		document.getElementById('s') && document.getElementById('s').focus();
	</script>

	</div><!-- #main -->

	<div id="footer" role="contentinfo">
		<div id="colophon">



			<div id="site-info">
				<a href="http://obf.edu.pl/en/" title="Centre for Philosophical Research" rel="home">
					Centre for Philosophical Research				</a>
							</div><!-- #site-info -->

			<div id="site-generator">
								<a href="https://wordpress.org/" class="imprint" title="Semantic Personal Publishing Platform">
					Proudly powered by WordPress.				</a>
			</div><!-- #site-generator -->

		</div><!-- #colophon -->
	</div><!-- #footer -->

</div><!-- #wrapper -->

<script type='text/javascript' src='http://obf.edu.pl/wp-content/plugins/jetpack/_inc/build/photon/photon.min.js?ver=20191001' id='jetpack-photon-js'></script>
<script type='text/javascript' id='jetpack-facebook-embed-js-extra'>
/* <![CDATA[ */
var jpfbembed = {"appid":"249643311490","locale":"en_US"};
/* ]]> */
</script>
<script type='text/javascript' src='http://obf.edu.pl/wp-content/plugins/jetpack/_inc/build/facebook-embed.min.js' id='jetpack-facebook-embed-js'></script>
<script type='text/javascript' src='http://obf.edu.pl/wp-includes/js/wp-embed.min.js?ver=5.7.12' id='wp-embed-js'></script>
<script src='https://stats.wp.com/e-202431.js' defer></script>
<script>
	_stq = window._stq || [];
	_stq.push([ 'view', {v:'ext',j:'1:10.4.1',blog:'78450485',post:'0',tz:'2',srv:'obf.edu.pl'} ]);
	_stq.push([ 'clickTrackerInit', '78450485', '0' ]);
</script>
</body>
</html>
